//all rigth recived for H.M Kosala Bandara Wijerathne.
//don't change script name(kbloader.js)

///////////////////////////////////////////////////////////////////////

//          (1).first add script file to your web page and then initiate below function
//              const kbLoaderInit = kbLoader();
//          (2).second call
//              kbLoaderInit.show();
//              kbLoaderInit.hide();

///////////////////////////////////////////////////////////////////////




function kbLoader() {
    var mainElmnt = document.createElement('div');
    mainElmnt.id = 'loaderUi';
    mainElmnt.style.position = 'fixed';
    mainElmnt.style.zIndex = 10000000;
    mainElmnt.style.width = '100px';
    mainElmnt.style.hight = '100px';
    mainElmnt.style.top = 'calc(50% - 50px)';
    mainElmnt.style.left = 'calc(50% - 50px)';
    var file = 'kbloader.js';
    var path = (src = (script = document.querySelector('script[src$="' + file + '"]')) ? script.src : 'Path/Not/Found/').substring(0, src.lastIndexOf("/") + 1);
    var img = new Image();
    img.src = path + "gear_duo.gif";
    img.style.width = "100px";
    img.style.hight = "100px";
    var elmn = document.createElement('h6');
    elmn.style.textAlign = "center";
    elmn.style.backgroundColor = "#03b1fc";
    elmn.style.padding = "5px";
    elmn.innerText = "Loading...";
    const showObj = {};
    showObj.show = function() {
        var myObj = document.getElementById('loaderUi');
        if (myObj == null) {
            document.querySelector('body').append(mainElmnt);
            document.getElementById('loaderUi').append(img);
            document.getElementById('loaderUi').append(elmn);
        }
    };
    showObj.hide = function() {
        var myObj = document.getElementById('loaderUi');
        if (myObj != null) {
            myObj.remove();
        }
    };
    return showObj;
}

function toDataURL(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function() {
        var reader = new FileReader();
        reader.onloadend = function() {
            callback(reader.result);
        }
        reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
}
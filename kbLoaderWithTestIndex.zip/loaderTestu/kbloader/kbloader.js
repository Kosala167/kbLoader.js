//H.M Kosala Bandara Wijerathne.
//don't change script name(kbloader.js)

///////////////////////////////////////////////////////////////////////

//          (1).first add script file to your web page
//          (2).second call
//              kbLoaderInit.show();
//              kbLoaderInit.hide();

///////////////////////////////////////////////////////////////////////




function kbLoader() {
    let clickBlocker = document.createElement('div');
    clickBlocker.id = 'clickBlockerByKb';
    clickBlocker.cssText = "position:fixed;z-index:9999999;width:100%;height:100%;top:0;left:0;background-color:red;";
    clickBlocker.style.position = 'fixed';
    clickBlocker.style.zIndex = '9999999';
    clickBlocker.style.width = '100%';
    clickBlocker.style.height = '100%';
    clickBlocker.style.top = '0';
    clickBlocker.style.left = '0';
    let mainElmnt = document.createElement('div');
    mainElmnt.id = 'loaderUi';
    mainElmnt.style.position = 'fixed';
    mainElmnt.style.zIndex = '10000000';
    mainElmnt.style.width = '100px';
    mainElmnt.style.height = '100px';
    mainElmnt.style.top = 'calc(50% - 50px)';
    mainElmnt.style.left = 'calc(50% - 50px)';
    let file = 'kbloader.js';
    let path = (src = (script = document.querySelector('script[src$="' + file + '"]')) ? script.src : 'Path/Not/Found/').substring(0, src.lastIndexOf("/") + 1);
    let img = new Image();
    img.src = path + "gear_duo.gif";
    img.style.width = "100px";
    img.style.height = "100px";
    let elmn = document.createElement('h6');
    elmn.style.textAlign = "center";
    elmn.style.backgroundColor = "#03b1fc";
    elmn.style.padding = "5px";
    elmn.innerText = "Loading...";
    const showObj = {};
    showObj.show = function() {
        let myObj = document.getElementById('loaderUi');
        if (myObj === null) {
            document.querySelector('body').append(clickBlocker);
            document.querySelector('body').append(mainElmnt);
            document.getElementById('loaderUi').append(img);
            document.getElementById('loaderUi').append(elmn);
        }
    };
    showObj.hide = function() {
        let myObj = document.getElementById('loaderUi');
        if (myObj !== null) {
            document.getElementById('clickBlockerByKb').remove();
            myObj.remove();
        }
    };
    return showObj;
}
const kbLoaderInit = kbLoader();